/* STATE */
let transactions = JSON.parse(localStorage.getItem("transactions")) || [
    {date:'2026-04-01', amount:5000, category:'Salary', type:'income'},
    {date:'2026-04-02', amount:1000, category:'Food', type:'expense'},
    {date:'2026-04-03', amount:2000, category:'Shopping', type:'expense'}
  ];
  
  let sortDirection = 1;
  
  /* SAVE TO LOCAL STORAGE */
  function saveData() {
    localStorage.setItem("transactions", JSON.stringify(transactions));
  }
  
  /* INIT */
  const trendChartCtx = document.getElementById('trendChart');
  const categoryChartCtx = document.getElementById('categoryChart');
  
  let trendChart, categoryChart;
  
  /* MAIN RENDER */
  function render() {
    renderCards();
    renderTable();
    renderCharts();
    renderInsights();
    handleRole();
  }
  
  /* CARDS */
  function renderCards() {
    let income = 0, expense = 0;
  
    transactions.forEach(t => {
      if (t.type === 'income') income += t.amount;
      else expense += t.amount;
    });
  
    document.getElementById('incomeCard').innerText = "Income: ₹" + income;
    document.getElementById('expenseCard').innerText = "Expense: ₹" + expense;
    document.getElementById('balanceCard').innerText = "Balance: ₹" + (income - expense);
  }
  
  /* TABLE */
  function renderTable() {
    const body = document.getElementById('tableBody');
    const search = document.getElementById('search').value.toLowerCase();
  
    body.innerHTML = '';
  
    let filtered = transactions.filter(t =>
      t.category.toLowerCase().includes(search)
    );
  
    document.getElementById('emptyState').style.display =
      filtered.length ? 'none' : 'block';
  
      filtered.forEach((t, index) => {
      body.innerHTML += `
        <tr>
          <td>${t.date}</td>
    <td>₹${t.amount}</td>
    <td>${t.category}</td>
    <td>${t.type}</td>
    <td>
      <button onclick="deleteTransaction(${index})">Delete</button>
    </td>

        </tr>
      `;
    });
  }
  
  /* SORT */
  function sortByAmount() {
    transactions.sort((a, b) => (a.amount - b.amount) * sortDirection);
    sortDirection *= -1;
    render();
  }
  
  function sortByDate() {
    transactions.sort((a, b) => (new Date(a.date) - new Date(b.date)) * sortDirection);
    sortDirection *= -1;
    render();
  }
  
  /* ADD */
  function addTransaction() {
    const role = document.getElementById('role').value;
    if (role !== 'admin') return alert("Only admin can add");
  
    const t = {
      date: date.value,
      amount: Number(amount.value),
      category: category.value,
      type: type.value
    };
  
    transactions.push(t);
    saveData();
    render();
  }
  
  /* ROLE */
  function handleRole() {
    const role = document.getElementById('role').value;
    document.getElementById('addSection').style.display =
      role === 'admin' ? 'block' : 'none';
  }
  function changeRole(value) {
    role = value;
    localStorage.setItem("role", role);
    render();
  }
  
  /* CHARTS */
  function renderCharts() {

    /* ===== GROUP BY MONTH-YEAR ===== */
    const monthlyData = {};
    const categoryMonthly = {};
  
    transactions.forEach(t => {
      const d = new Date(t.date);
      const key = d.toLocaleString('default', { month: 'short', year: 'numeric' });
// Example: "Apr 2026"
  
      // Balance Trend (Income - Expense per month)
      if (!monthlyData[key]) {
        monthlyData[key] = 0;
      }
  
      if (t.type === 'income') {
        monthlyData[key] += t.amount;
      } else {
        monthlyData[key] -= t.amount;
      }
  
      // Spending Breakdown (per month + category)
      if (t.type === 'expense') {
        if (!categoryMonthly[key]) {
          categoryMonthly[key] = {};
        }
  
        if (!categoryMonthly[key][t.category]) {
          categoryMonthly[key][t.category] = 0;
        }
  
        categoryMonthly[key][t.category] += t.amount;
      }
    });
  
    /* ===== SORT MONTHS ===== */
    const sortedMonths = Object.keys(monthlyData).sort();
  
    /* ===== BALANCE TREND CHART ===== */
    if (trendChart) trendChart.destroy();
  
    trendChart = new Chart(trendChartCtx, {
      type: 'line',
      data: {
        labels: sortedMonths,
        datasets: [{
          label: 'Monthly Balance',
          data: sortedMonths.map(m => monthlyData[m]),
          tension: 0.4
        }]
      }
    });
  
    /* ===== SPENDING BREAKDOWN (LATEST MONTH) ===== */
    /* ===== SPENDING BREAKDOWN (LATEST MONTH) ===== */

/* ===== SPENDING BREAKDOWN (LATEST MONTH) ===== */

const latestMonth = sortedMonths.length 
  ? sortedMonths[sortedMonths.length - 1] 
  : null;

let categoryData = {};

if (latestMonth && categoryMonthly[latestMonth]) {
  categoryData = categoryMonthly[latestMonth];
}

/* Convert to arrays */
const labels = Object.keys(categoryData);
const values = Object.values(categoryData);

/* Fix: ensure chart updates even if empty */
if (labels.length === 0) {
  labels.push("No Data");
  values.push(1);
}

/* DESTROY OLD CHART */
if (categoryChart) {
  categoryChart.destroy();
}
/* CREATE NEW CHART */
categoryChart = new Chart(categoryChartCtx, {
  type: 'doughnut',
  data: {
    labels: labels,
    datasets: [{
      data: values
    }]
  },
  options: {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom'
      }
    },
    layout: {
      padding: 30
    },
    cutout: '60%',   // makes donut thinner (reduces size feel)
    radius: '100%'    // 🔥 THIS shrinks the pie chart
  }
});
};
  

  
  /* INSIGHTS */
  function renderInsights() {
    let categoryTotal = {};
  
    transactions.forEach(t => {
      if (t.type === 'expense') {
        categoryTotal[t.category] =
          (categoryTotal[t.category] || 0) + t.amount;
      }
    });
  
    let maxCat = Object.keys(categoryTotal)
      .reduce((a,b)=> categoryTotal[a]>categoryTotal[b]?a:b, "None");
  
    document.getElementById('insights').innerHTML = `
      <li>Highest spending category: ${maxCat}</li>
      <li>Total transactions: ${transactions.length}</li>
    `;
  }
  
  /* EVENTS */
  document.getElementById('search').addEventListener('input', render);
  document.getElementById('role').addEventListener('change', render);
  
  /* INIT */
  render();
  function deleteTransaction(index) {
    transactions.splice(index, 1);
    saveData();
    render();
  }
  function scrollTable(value) {
    document.getElementById("tableScroll").scrollBy({
      left: value,
      behavior: "smooth"
    });
  }
 