# Finance Dashboard

## Features
- Summary cards (Balance, Income, Expense)
- Balance trend chart (monthly)
- Spending breakdown (monthly pie chart)
- Transaction table with search and sorting
- Add transaction (Admin role)
- Role-based UI (Viewer/Admin)
- LocalStorage support (data persists)
- Responsive dark theme UI

## Technologies Used
- HTML
- CSS
- JavaScript
- Chart.js

## How to Run
1. Open index.html in browser
2. Add transactions
3. Switch roles using dropdown

## Notes
- Viewer: Only view data
- Admin: Can add transactions